package com.sp.BookLoginMicroserviceProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookLoginMicroserviceProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookLoginMicroserviceProjectApplication.class, args);
	}

}
