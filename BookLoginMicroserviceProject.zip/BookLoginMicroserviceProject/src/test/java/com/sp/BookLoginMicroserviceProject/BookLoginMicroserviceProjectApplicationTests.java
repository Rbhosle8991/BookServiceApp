package com.sp.BookLoginMicroserviceProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookLoginMicroserviceProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
