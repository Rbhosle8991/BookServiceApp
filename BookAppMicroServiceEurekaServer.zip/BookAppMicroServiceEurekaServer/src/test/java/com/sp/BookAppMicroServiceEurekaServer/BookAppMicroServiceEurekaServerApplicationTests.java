package com.sp.BookAppMicroServiceEurekaServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookAppMicroServiceEurekaServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
