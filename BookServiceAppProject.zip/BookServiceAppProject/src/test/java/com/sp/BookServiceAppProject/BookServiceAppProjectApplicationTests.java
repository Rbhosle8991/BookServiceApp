package com.sp.BookServiceAppProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookServiceAppProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
