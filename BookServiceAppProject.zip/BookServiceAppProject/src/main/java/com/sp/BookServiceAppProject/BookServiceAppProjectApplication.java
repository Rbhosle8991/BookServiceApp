package com.sp.BookServiceAppProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookServiceAppProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookServiceAppProjectApplication.class, args);
	}

}
